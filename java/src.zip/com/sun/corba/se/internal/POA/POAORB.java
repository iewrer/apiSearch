/*
 * Copyright (c) 1997, 2003, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.corba.se.internal.POA;

/**
 * Deprecated class for backward compatibility.
 */
public class POAORB extends com.sun.corba.se.internal.iiop.ORB
{
    public POAORB( )
    {
        super();
    }
}
